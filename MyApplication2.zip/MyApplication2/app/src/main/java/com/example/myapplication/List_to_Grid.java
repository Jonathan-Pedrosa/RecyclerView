package com.example.myapplication;

class List_to_Grid {

    public static final int LIST=1;
    public static final int GRID=2;

    public static int visualizacion=LIST;

}